// Corrected CommonJS module pattern
module.exports.autozone = (req, res) => {
    let message = req.query.message || req.body.message || 'Hello Auto Zone!';
    res.status(200).send(message);
  };
  